package vista;

public class Constantes {
	public static final int ventana_x_size=630;
	public static final int ventana_y_size=480;
	public static final int x_size =630;
	public static final int y_size =400;
}
